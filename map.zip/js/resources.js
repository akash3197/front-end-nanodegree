var myPlaces=[
    {
    name: "Backpackers Cafe",
    lat: 30.705220,
    lng: 76.801207,
    show: true,
    selected: false,
    venuId: "4ba37b0ff964a520b94038e3"
    },
    {
    name: "Elante Mall",
    lat: 30.705587,
    lng: 76.801271,
    show: true,
    selected: false,
    venuId: "5114cd90e4b06bb0ed15a97f"
    },
    {
    name: "Barbeque Nation",
    lat: 30.726038,
    lng: 76.805337,
    show: true,
    selected: false,
    venuId: "4bbf61eef353d13a29837e10"
    },
    {
    name: "Rock Garden",
    lat: 30.752535,
    lng: 76.810104,
    show: true,
    selected: false,
    venuId: "4b6fe660f964a5206dff2ce3"
    },
    {
    name: "Nik Bakers",
    lat: 30.721527,
    lng: 76.760193,
    show: true,
    selected: false,
    venuId: "4bd6f81229eb9c7429e295e1"
    },
    {
    name: "Mainland China",
    lat: 30.725223,
    lng: 76.805650,
    show: true,
    selected: false,
    venuId: "4b8a5453f964a520bb6832e3"
    },
    {
    name:"Barista",
    lat: 30.722340,
    lng: 76.761303,
    show: true,
    selected: false,
    venuId: "4bdc26062a3a0f4742a2b1b6"
    },
    {
    name: "Zara",
    lat: 30.706073,
    lng: 76.800684,
    show: true,
    selected: false,
    venuId:"515eda33e4b02caa2710c970"
    },
    {
    name: "Cafe Nomad",
    lat: 30.732942,
    lng: 76.803215,
    show: true,
    selected: false,
    venuId: "4c139af9a1010f4737d84a18"
    },
    {
    name: "Rose Garden",
    lat: 30.746114,
    lng: 76.781977,
    show: true,
    selected: false,
    venuId:"4c0ba827009a0f47975cebbf"
    },
    {
    name: "Dunkin Donuts",
    lat: 30.728846,
    lng: 76.845080,
    show: true,
    selected: false,
    venuId: "514c6e31e4b0c959305adc80"
    },
    {
    name: "Gopal Sweets",
    lat: 30.721134,
    lng: 76.759540,
    show: true,
    selected: false,
    venuId: "4c2ffb2e66e40f4710f5c28b"
    },
    {
    name: "Hops n Grains",
    lat: 30.697811,
    lng: 76.849384,
    show: true,
    selected: false,
    venuId: "4d1f20ec2eb1f04ded06e6c1"
    },
    {
    name: "Books And Brew",
    lat: 30.746963,
    lng: 76.775877,
    show: true,
    selected: false,
    venuId: "4ccbd49fba79a1cd731037cb"
    }
];
var viewModel = function() {

  var self = this;

  self.errorDisplay = ko.observable('');

  // populates the  mapList with every Model
  self.mapList = [];
  myPlaces.forEach(function(marker){
    self.mapList.push(new google.maps.Marker({
      position: {lat: marker.lat, lng: marker.lng},
      map: map,
      name: marker.name,
      show: ko.observable(marker.show),  // sets observable for checking
      selected: ko.observable(marker.selected),
      venuId: marker.venuId,   // foursquare id
      animation: google.maps.Animation.DROP
    }));
  });

  //stores the mapList length
  self.mapListLength = self.mapList.length;

  //set current map item
  self.currentMapItem = self.mapList[0];

  // function to make marker bounce but stop after the delay of 900ms
  self.makeBounce = function(marker){
    marker.setAnimation(google.maps.Animation.BOUNCE);
    setTimeout(function(){ marker.setAnimation(null);}, 900);
  };

  // function to add API information to each marker
  self.addApiInfo = function(passMark){
      $.ajax({
        url: "https://api.foursquare.com/v2/venues/" + passMark.venuId + '?client_id=11QKRX0VEXHGWZ30NBK3VQ4EOG0KTAGFMR1F5NLJFPXNUKZX&client_secret=UFI5TKZIISKHTEWENGH4S5WBMG4HTVZCOSDR1ITKGQWPAEVT&v=20170514',
        dataType: "json",//foresquare id and client
        success: function(data){
          // store results to display likes and ratings
          var result = data.response.venue;
          // add likes and ratings to marker
          passMark.likes = result.hasOwnProperty('likes') ? result.likes.summary: "";
          passMark.rating = result.hasOwnProperty('rating') ? result.rating: "";
        },
        //alert if there is any  error in recievng json
        error: function(e) {
          self.errorDisplay("Foursquare data is unavailable. Please try again later.");
        }
      });
  };
    // iterates through mapList and add marker event listener and API information
  for (var i=0; i < self.mapListLength; i++){
    (function(passMark){
            self.addApiInfo(passMark);
            //add the click event listener to mapMarker
            passMark.addListener('click', function(){
                self.setSelected(passMark);
            });
        })(self.mapList[i]);
  }

  self.filterText = ko.observable('');
  self.applyFilter = function() {
    var currentFilter = self.filterText();
    infowindow.close();
    //filter the list as user seach
    if (currentFilter.length === 0) {
            self.setAllShow(true);
        } else {
            for (var i = 0; i < self.mapListLength; i++) {
                if (self.mapList[i].name.toLowerCase().indexOf(currentFilter.toLowerCase()) > -1) {
                    self.mapList[i].show(true);
                    self.mapList[i].setVisible(true);
                } else {
                    self.mapList[i].show(false);
                    self.mapList[i].setVisible(false);
                }
            }
    }
    infowindow.close();
  };
  // to make all markers visible
  self.setAllShow = function(showVar) {
    for (var i = 0; i < self.mapListLength; i++) {
      self.mapList[i].show(showVar);
      self.mapList[i].setVisible(showVar);
    }
  };
  self.setAllUnselected = function() {
        for (var i = 0; i < self.mapListLength; i++) {
            self.mapList[i].selected(false);
        }
    };
  self.setSelected = function(location) {
        self.setAllUnselected();
        location.selected(true);
        self.currentMapItem = location;
        formattedLikes = function() {
            if (self.currentMapItem.likes === "" || self.currentMapItem.likes === undefined) {
                return "No likes to display";
            } else {
                return "Location has " + self.currentMapItem.likes;
            }
        };
        formattedRating = function() {
            if (self.currentMapItem.rating === "" || self.currentMapItem.rating === undefined) {
                return "No rating to display";
            } else {
                return "Location is rated " + self.currentMapItem.rating;
            }
        };
        var formattedInfoWindow = "<h5>" + self.currentMapItem.name + "</h5>" + "<div>" + formattedLikes() + "</div>" + "<div>" + formattedRating() + "</div>";
        infowindow.setContent(formattedInfoWindow);
        infowindow.open(map, location);
        self.makeBounce(location);
    };
};