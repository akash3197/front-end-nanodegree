#Neighbourhood Map Project
About project:The Goal of this Project is to Make a Map of a Neighborhood Showing My Favorite Places.
In this project we use many api's.
My map shows some of the famous location of Chandigarh.

Api's and framewroks:
kockout js,jQuery,gooogle map api,foursquare api.

Steps to run this :
open index.html
click on the list to get the location.