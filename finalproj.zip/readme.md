Testing project:
this is all about testing and my final project
Feed Reader:
In this project jasmine testing Suite is used to test for various conditions.
Testing is done in 7-10seconds
How to open:
go to feedreader and open index.html.
all tests must be runing and there should be no error.